package builder;

public class Director {
	public void makeCarroNormal(Builder builder) {
		builder.reset();
		builder.setBancos(4);
		builder.setMotor("1.0");
	}
	public void makeCarroEsportivo(Builder builder) {
		builder.reset();
		builder.setBancos(2);
		builder.setMotor("v8");
		builder.setGPS("GPS Premium");
		builder.setCompBordo("CB Esportivo");
		
	}
}
