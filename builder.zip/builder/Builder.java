package builder;

public interface Builder {
	void reset();
	void setMotor(String motor);
	void setGPS(String gps);
	void setCompBordo(String cb);
	void setBancos(int bancos);
	Carro getResult();

}
