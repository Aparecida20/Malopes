package builder;

public class BuilderCarroNormal implements Builder{
	private Carro carro;
	
	public void reset() {
		carro = new Carro();
	}
	public void setMotor(String motor) {
		carro.setMotor(motor);
	}
	public void setGPS(String gps) {
		carro.setGPS(gps);
	}
	public void setCompBordo(String cb) {
		carro.setComputadorDeBordo(cb);
	}
	public void setBancos(int bancos) {
		carro.setBancos(bancos);
	}
	public Carro getResult() {
		return carro;
	}
}
