package builder;

public class Carro {
	private String motor;
	private String gps;
	private String computadorDeBordo;
	private int bancos;
	
	public void setMotor(String motor) { this.motor = motor;}
	public void setGPS(String gps) { this.gps = gps;}
	public void setComputadorDeBordo(String cb) { this.computadorDeBordo = cb;}
	public void setBancos(int bancos) { this.bancos = bancos;}
	
	public String toString() {
		return "Carro [motor=" + motor +", bancos=" + bancos + ",GPS=" + gps + ", Computador de Bordo=" + computadorDeBordo + "]";
			
	}
}
