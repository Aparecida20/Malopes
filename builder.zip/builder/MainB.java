package builder;

public class MainB {
	public static void main(String[] args) {
		Director diretor = new Director();
		BuilderCarroNormal builderNormal = new BuilderCarroNormal();
		
		diretor.makeCarroNormal(builderNormal);
		Carro carroNormal = builderNormal.getResult();
		System.out.println("Carro Normal: " + carroNormal);
		
		BuilderCarroNormal builderEsportivo = new BuilderCarroNormal();
		diretor.makeCarroEsportivo(builderEsportivo);
		Carro carroEsportivo = builderEsportivo.getResult();
		System.out.println("Carro Esportivo: " + carroEsportivo);
	}
}
