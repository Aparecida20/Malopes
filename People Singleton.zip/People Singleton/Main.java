package People;

public class Main {
	public static void main(String[] args) {
		ListaFesta lf = ListaFesta.getInstance();
		lf.show();
	}

}
