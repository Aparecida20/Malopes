package People;

import java.util.ArrayList;

public class Pessoa {
		String nome;
		
		public Pessoa(String nome){
			this.nome = nome;
		}
	public Pessoa(){
		
	}

}
