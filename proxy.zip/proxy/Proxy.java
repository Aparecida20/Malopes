package proxy;

public class Proxy implements ServiceInterface{
	private Service realService;
	
	public Proxy(Service s) {
		this.realService = s;
	}
	private boolean checkAccess() {
		System.out.println("Proxy: verificando acesso...");
		return true;
	}
	public void operation() {
		if(checkAccess()) {
			realService.operation();
		}else {
			System.out.println("Acesso negado pelo proxy");
		}
	}
}
