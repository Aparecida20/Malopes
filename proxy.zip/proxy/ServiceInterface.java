package proxy;

public interface ServiceInterface {
	void operation();
}
