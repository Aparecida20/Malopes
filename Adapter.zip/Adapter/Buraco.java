package adapter;

public class Buraco {

	public Buraco() {
		// TODO Auto-generated constructor stub
	}

}
