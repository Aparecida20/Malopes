package adapter;

public class Cubo {
	private int lado;
	
	public Cubo(int lado){
		this.lado = lado;
	}
	public int getLado(){
		return this.lado;
	}

}
