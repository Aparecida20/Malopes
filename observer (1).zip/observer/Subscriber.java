package observer;

public interface Subscriber {
	void update(Publisher context);
}